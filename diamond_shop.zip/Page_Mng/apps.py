from django.apps import AppConfig


class PageMngConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Page_Mng'
